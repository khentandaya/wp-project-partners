jQuery( document ).ready( function( $ ) {
    $( '#learndash-memberpress-associated-memberships-meta-box .select2' )
    .select2({
        placeholder: LD_Memberpress_Edit_Post_Params.placeholder,
        // dropdownParent: $( '#learndash-memberpress-associated-memberships-meta-box' ),
    } );
} );